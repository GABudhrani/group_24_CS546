# group_24_CS546

## Name
BOOM Video Conferencing

## Description
Boom provides tutoring and other educational support
via a remote platform designed specifically to engage
and captivate learners and empower educators.

## Features
- The main feature of this app is to provide multiuser video conferencing. 

- Only authorized and authenticated user will be able to join the meeting.

- It is free!!

- The app provides chat funtionality, which enables student to ask doubts and communicate with others without disturbing the whole class.
## Usage

Clone the application using https://github.com/GABudhrani/group_24_CS546.git. Run 'npm install' to install the required dependencies for our project. After that run npm start to run project on localhost.


